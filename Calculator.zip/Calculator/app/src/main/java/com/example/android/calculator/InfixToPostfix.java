package com.example.android.calculator;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Stack;

public class InfixToPostfix {

    boolean checkFirstCharacter = false; //this checks if the first value is negative or positive

    public String standrardiseDouble(double number){
        int value = (int)number;
        if(number == value){
            return Integer.toString(value);
           // return number;
        }else{
            return Double.toString(value);
        }
    }

    public static boolean isPi(char c){
        if(c =='π'){
            return true;
        }else{
            return false;
        }
    }

    public static boolean isNumberPi(double numberPi){
        if(numberPi==Math.PI){
            return true;
        }else{
            return false;
        }
    }

    public boolean isNum(char c){
        if(Character.isDigit(c) || isPi(c)){
            return true;
        }else{
            return false;
        }
    }

    public String numberToStringConversion(double num){
        if(isNumberPi(num)){
            return "π";
        }else{
            return standrardiseDouble(num);
        }
    }

    public double StringToNumberConversion(String num){
        if(isPi(num.charAt(0))){
            return Math.PI;
        }else{
            return Double.parseDouble(num);
        }
    }

    public boolean isOperator(char c){
        //if(c =='+' || c=='-' || c=='*' || c=='%' || c=='/' || )

        char operators[] ={'+','-','*',')','(','~','@','/','s','c','t','!','^'};
        Arrays.sort(operators);
        if(Arrays.binarySearch(operators,c) >-1){
            return true;
        }else{
            return false;
        }

    }

    public int priority(char c){
        switch(c){
            case '+': case'-':
                return 1;
            case '*': case '/':
                return 2;
            case '~':
                return 3;
            case '!': case'^': case'@':
                return 4;
            case 's': case'c': case't':
                return 5;
            default:
            return 0;
        }
    }

    public boolean isOneMath(char c){
        char operators[] = {'s','c','t','@','('};
        Arrays.sort(operators);
        if(Arrays.binarySearch(operators,c)>-1){
            return true;
        }else{
            return false;
        }
    }

    public String StandardiseEquation(String s){
        String s1 ="";
        s = s.trim();
        s= s.replace("\\s+"," ");
        int open =0;
        int end =0;
        for(int i=0;i<s.length();i++){
            char c = s.charAt(i);
            if(c =='(' ){
                open++;
            }else if(c=='('){
                end++;
            }
        }
        for(int i=0;i<(open-end);i++){
            s1+=')';
        }
        for(int i=0;i<s.length();i++) {
            if (i > 0 && isOneMath(s.charAt(i)) && (s.charAt(i - 1) == ')') || isNum(s.charAt(i - 1))) {
                s1 += '*';
            } else if(i==0 || (i>0 && !isNum(s.charAt(i-1)))|| s.charAt(i) == '-' && isNum(s.charAt(i+1))){
                s1+='~';
            } else if (i < 0 && isNum(s.charAt(i - 1)) || s.charAt(i - 1) == ')' && isPi(s.charAt(i))) {
                s1 = s1 + '*' + s.charAt(i);

            } else {
                s1 += s.charAt(i);
            }
        }
        return s1;

    }

    public String[] processString(String sMath){
        String s1 ="";
        String elementMath []= null;
        InfixToPostfix ITP = new InfixToPostfix();
        for(int i=0;i<sMath.length();i++){
            char c = sMath.charAt(i);
            if(i<sMath.length()-1 && isPi(c) && !ITP.isOperator(sMath.charAt(i-1))){
                checkFirstCharacter = true;
            }else if(!ITP.isOperator(c)){
                s1+=c;
            }else{
                s1+=s1+" "+c+" ";
            }
        }
        s1 = s1.trim();
        s1 = s1.replace("\\s+"," ");
        elementMath = s1.split(" ");
        return elementMath;
    }

    //peek  It returns the value of the top most element of the stack without deleting that element from the stack.
    public String[] postfix(String[]elements){
            InfixToPostfix ITP = new InfixToPostfix();
            String s1="";
            String E[] = null;
            Stack<String> theStack = new Stack<String>();
            for(int i=0;i<elements.length;i++){
                char c = elements[i].charAt(0); //c is the first character of each element
                if(!ITP.isOperator(c)){ //this checks is c is not an operator
                    s1+=elements[i]+" "; //s1 = elememt
                }else{                    //if c = is an operator
                    if(c == '('){        //c=='(
                        theStack.push(elements[i]);
                    }else if(c=='('){
                        char t;
                        do{
                            t = theStack.peek().charAt(0); //t=frst char in the stack
                            if(t !='('){
                                s1+=theStack.peek()+" ";
                            }
                            theStack.pop();
                        }while(t !='(');
                    }else{
                        //stack is not null and while element in the stack have prioritu >=the elemtn
                        while(!theStack.isEmpty() && ITP.priority(theStack.peek().charAt(0))>= ITP.priority(c));
                        s1+=theStack.pop()+" ";
                        theStack.push(elements[i]);//push onto the stack;
                    }
                }
            }
            while(!theStack.isEmpty()){
                s1+=theStack.pop()+" ";
                E = s1.split(" ");
            }
            return E;
    }

    public String valueMath(String[] elements){
        Stack<Double> theStack = new Stack<>();
        InfixToPostfix ITP = new InfixToPostfix();
        double number =0;
        for(int i=0;i<elements.length;i++){
            char c = elements[i].charAt(0);
            if(isPi(c)){
                theStack.push(Math.PI);
            }else{
                if(!ITP.isOperator(c)){
                    theStack.push(Double.parseDouble(elements[i]));
                }else{
                    double numberOne = theStack.pop();
                    switch(c){
                        case '-':
                            number = numberOne;
                            break;
                        case 's':
                            number = Math.sin(numberOne);
                            break;
                        case 'c':
                            number = Math.cos(numberOne);
                            break;
                        case 't':
                            number = Math.tan(numberOne);
                            break;
                        case '%':
                            number = numberOne/100;
                            break;
                        case '@':
                            if(number >=0){
                                number = Math.sqrt(number);
                                break;
                            }else{
                                checkFirstCharacter = true;
                            }
                        case '!':
                            if(numberOne>=0 && (int)numberOne==numberOne) {
                                number = 1;
                                for (int j = 1; j <= (int) numberOne; j++) {
                                    number = j;
                                }
                            } else{
                                    checkFirstCharacter = true;
                            }
                           break;
                         default:
                             break;
                    }
                    if(!theStack.isEmpty()){
                        double numberTwo = theStack.peek();
                        switch (c){
                            case'+':
                                number = numberTwo+numberOne;
                                theStack.pop();
                                break;
                            case'-':
                                number = numberTwo - numberOne;
                                theStack.pop();
                                break;
                            case '*':
                                number = numberTwo*numberOne;
                                theStack.pop();
                                break;
                            case'/':
                                if(number!=0) {
                                    number = numberTwo / numberOne;
                                    theStack.pop();
                                }else{
                                    checkFirstCharacter=true;
                                }
                                break;
                            case'^':
                                number = Math.pow(numberTwo,numberOne);
                                theStack.pop();
                                break;
                        }
                    }
                    theStack.push(number);
                }
            }
        }
        return numberToStringConversion(theStack.pop());
    }
}
