package com.example.android.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import me.anwarshahriar.calligrapher.Calligrapher;


public class MainActivity extends AppCompatActivity {

    Button btnSin,btnCos,btnTan,btnFactorial,btnPower;
    Button btnclear,btnblankSpace,btnopen,btnclose,btnSquare;
    Button btnseven,btneight,btnnine,btndive,btnmod;
    Button btnfour,btnfive,btnsix,btnadd,btnfact;
    Button btnone,btnTwo,btnThree,btnminus,btndividor;
    Button btnon,btn0,btnn,btnmultiply,btnpi;


    TextView screenAns,screenMath;

    StringBuilder textMath = new StringBuilder("");
    StringBuilder textAns = new StringBuilder("0");
    StringBuilder screen = new StringBuilder("");
    double numberOne=0;
    double number =0;
    double numberTwo=0;

    int checksum =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main);

        Calligrapher calligrapher = new Calligrapher(this);
        calligrapher.setFont(this,"AlexBrush-Regular.ttf",true);

        screenAns = (TextView) findViewById(R.id.textResult);
        screenMath = (TextView)findViewById(R.id.textCal);





    }
}
